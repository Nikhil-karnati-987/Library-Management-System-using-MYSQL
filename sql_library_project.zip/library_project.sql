create database Library;
use Library;
create table publisher ( publisherName varchar(255) primary key ,
						publisherAddress varchar(255) ,
                        publisherPhone varchar(255));
                        
describe publisher;


create table library_branch ( branchID tinyint primary key auto_increment,
							BranchName varchar(255) ,
                            branchaddress varchar(255));
describe library_branch;


create table borrower ( CardNo tinyint primary key ,
						BorrowerName varchar(255) ,
                        BorrowerAddress varchar(255),
                        BorrowerPhone varchar(255));
                        
describe borrower;

create table book ( bookID tinyint primary key ,
					Title varchar(255) ,
                    publishername varchar(255),
                    foreign key (publishername) references publisher(publishername) on update cascade
                    on delete cascade);
describe book;


 create table authors ( AuthorID tinyint primary key auto_increment,
						bookID tinyint,
                        AuthorName varchar(255),
                        foreign key(bookID) references book (bookID) on update cascade on delete cascade);
describe authors;



create table copies ( CopiesID tinyint primary key auto_increment,
						BookID tinyint,
                        BranchID tinyint,
                        no_of_copies tinyint,
                        foreign key (BookID) references book(BookID) on update cascade on delete cascade);
describe copies;

create table  book_loans ( loanID tinyint primary key auto_increment,
							BookID tinyint,
                            BranchID tinyint,
                            CardNo tinyint,
                            DateOut date,
                            DueDate date,
                            foreign key(BookID) references book(bookID) on update cascade on delete cascade,
                            foreign key (BranchID) references library_branch (BranchID) on update cascade on delete cascade,
                            foreign key (cardNo) references borrower (cardNo) on update cascade on delete cascade);
describe book_loans;

select * from authors;
select * from book;
select * from library_branch;
select * from publisher;
select * from book_loans;
select * from copies;
select * from borrower;

-- Task.
/*1. How many copies of the book titled "The Lost Tribe" are owned by 
the library branch whose name is "Sharpstown"?*/

select no_of_copies from copies
join library_branch
on library_branch.branchid = copies.branchid
join book on
book.bookid = copies.bookid
where  branchName = 'Sharpstown' AND title = 'The Lost Tribe';



use library;
-- 2. How many copies of the book titled "The Lost Tribe" are owned by each library branch?

select sum(copies.no_of_copies) as total_copies,branchname from
copies
join library_branch
on library_branch.branchid = copies.branchid
join book
on book.bookid = copies.bookid
where book.title = 'The Lost Tribe'
group by branchname;

-- 3. Retrieve the names of all borrowers who do not have any books checked out?
select borrower.borrowerName,
borrower.cardNo from borrower
left join book_loans
on book_loans.cardno = borrower.cardno
where book_loans.cardno is null;

-- 4. For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, the borrower's name, and the borrower's address?
with cte_2 as (with cte_1 as (select library_branch.branchid,branchname,cardno,bookid
from library_branch
  join book_loans
on book_loans.branchid = library_branch.branchid
where branchname = 'Sharpstown' AND duedate = '0002-03-18')

select cte_1.bookid,title,cardno from cte_1
join book
on book.bookid = cte_1.bookid)
select borrowername,borroweraddress,title from cte_2
join borrower
on cte_2.cardno = borrower.cardno;


-- 5.For each library branch, retrieve the branch name and the total number of books loaned out from that branch?
select library_branch.branchid,branchname,sum(no_of_copies) from library_branch
join copies
on library_branch.branchid = copies.branchid
group by library_branch.branchid,branchname;


-- 6. Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out?
with cte_1 as (select cardno,no_of_copies from book_loans
 join copies
on book_loans.branchid = copies.branchid
where no_of_copies >5)
select borrowername,borroweraddress,no_of_copies from cte_1
join borrower
on borrower.cardno = cte_1.cardno;

-- 7.For each book authored by "Stephen King", retrieve the title and the number of copies owned by the library branch whose name is "Central"?
with cte_2 as (with cte_1 as (select branchid,authorname,authors.bookid,no_of_copies from copies
join authors
on authors.bookid = copies.bookid
where authorname = 'Stephen King')
select cte_1.bookid,title,authorname,branchid,no_of_copies from cte_1
join book
on cte_1.bookid = book.bookid)
select authorname,no_of_copies,title,branchname from cte_2
join library_branch
on library_branch.branchid = cte_2.branchid
where branchname = 'Central';







select * from authors;
select * from book;
select * from library_branch;
select * from publisher;
select * from book_loans;
select * from copies;
select * from borrower;




					